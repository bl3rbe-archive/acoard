# Credits

## DClone Icon - @nwlandas

## LINEICONS FREE TERMS
1. Commercial and Personal Use - Allowed
2. Redistribution with Projects - Allowed
3. Credits/Attribution - Required
4. Reselling or Redistributing as 'Icon Pack/Icon' from Other Sources - NOT Allowed

https://lineicons.com/license/