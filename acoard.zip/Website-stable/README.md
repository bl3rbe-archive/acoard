# Accord - Website
Seamless chat website built from the [2PG Dashboard](https://github.com/twopg/Dashboard), like Discord.

![Lines of Code](https://img.shields.io/tokei/lines/github/d-clone/Website?color=46828d&style=for-the-badge)

> © All rights reserved. This repo is not (yet) open source, and is awaiting completion.

Creating Discord Series - https://www.youtube.com/watch?v=F9wHO4QOfEU&list=PLGfT2ttRbfixrbgkKa0h9bkSz5BzE1npG&index=1

**Project is currently incomplete and awaiting major updates.**