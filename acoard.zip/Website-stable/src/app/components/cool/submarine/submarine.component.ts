import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-submarine',
  templateUrl: './submarine.component.html',
  styleUrls: ['./submarine.component.css']
})
export class SubmarineComponent {}
