import { Component } from '@angular/core';

@Component({
  selector: 'app-lighthouse',
  templateUrl: './lighthouse.component.html',
  styleUrls: ['./lighthouse.component.css']
})
export class LighthouseComponent {}
