import { Component, Input, OnInit } from '@angular/core';
import { PermissionsService } from 'src/app/services/perms.service';
import { GuildService } from '../../../../services/api/guild.service';
import { UserService } from 'src/app/services/api/user.service';
import { PingService } from 'src/app/services/ping.service';
import { ChannelService } from 'src/app/services/api/channel.service';
import { DialogService } from 'src/app/services/dialog.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Lean } from 'src/app/types/entity-types';
import { Args, WSService } from 'src/app/services/ws.service';
import { ConfigService } from 'src/app/services/config.service';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';

@Component({
  selector: 'guild-sidebar',
  templateUrl: './guild-sidebar.component.html',
  styleUrls: ['./guild-sidebar.component.css']
})
export class GuildSidebarComponent implements OnInit {
  @Input('waitFor')
  public loaded = true;

  public guild: Lean.Guild;

  public get textChannels() {
    return this.guild.channels.filter(c => c.type === 'TEXT');
  }
  public get voiceChannels() {
    return this.guild.channels.filter(c => c.type === 'VOICE');
  }

  constructor(
    public config: ConfigService,
    public route: ActivatedRoute,
    public channelService: ChannelService,
    public guildService: GuildService,
    public perms: PermissionsService,
    public userService: UserService,
    public pings: PingService,
    public dialog: DialogService,
    private router: Router,
    private ws: WSService,
  ) {}

  public async ngOnInit() {
    this.route.paramMap.subscribe(async (paramMap) => {
      const guildId = paramMap.get('guildId');
      this.guild = this.guildService.getCached(guildId);
      
      const inGuild = this.guildService.getSelfMember(guildId);
      if (!inGuild)
        await this.router.navigate(['/channels/@me']);
    });

    this.ws
      .on('GUILD_DELETE', this.returnFromGuild, this)
      .on('GUILD_LEAVE', this.returnFromGuild, this);
  }

  public async moveChannel(event: CdkDragDrop<Lean.Channel[]>) {
    await this.guildService.reorder(this.guild, 'channels', event);
  }

  private async returnFromGuild({ guildId }: Args.GuildDelete | Args.GuildLeave) {
    if (guildId !== this.guild.id) return;

    await this.router.navigate(['/channels/@me']);
  }
}
