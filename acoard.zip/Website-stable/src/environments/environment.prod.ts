export const environment = {
  docsURL: 'https://docs.accord.app',
  endpoint: '/api/v1',
  rootEndpoint: '/',
  githubURL: 'https://github.com/accorddotapp',
  production: true,
  statusURL: 'https://accord.statuspage.io',
  version: 'v0.2.1a',
};
